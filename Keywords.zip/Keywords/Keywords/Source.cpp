#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>

using namespace std;


int main()
{
	string guessOne;
	string guessTwo;
	string guessThree;
	
	//Creating the list of code words and Hints
	enum fields { WORD, HINT, NUM_FIELDS };
	const int NUM_WORDS = 10;
	const string WORDS[NUM_WORDS][NUM_FIELDS] =
	{
		{"Tango", "Dancing with the enemy."},
		{"Awful", "How it feels to live in New York"},
		{"Sierra", "Mist"},
		{"Whiskey", "Take a shot"},
		{"Metric", "The superior measurement system"},
		{"Echo", "The dolphin"},
		{"Melee", "Better than Ultimate"},
		{"Polytonal", "Using more than one key center"},
		{"November", "Next month"},
		{"Meteor", "Killed the dinosaurs"},
	};

	//Picking a random word from my list of words
	srand(static_cast<unsigned int>(time(0)));
	int choice = (rand() % NUM_WORDS);
	string theWord = WORDS[choice][WORD];
	string theHint = WORDS[choice][HINT];
	string theWordTwo = WORDS[choice][WORD];
	string theHintTwo = WORDS[choice][HINT];
	string theWordThree = WORDS[choice][WORD];
	string theHintThree = WORDS[choice][HINT];
	
	//Scrambling the word
	string jumble = theWord;
	int length = jumble.size();
	for (int i = 0; i < length; ++i)
	{
		int index1 = (rand() % length);
		int index2 = (rand() % length);
		char temp = jumble[index1];
		jumble[index1] = jumble[index2];
		jumble[index2] = temp;
	}

	//Introduce game to the player
	cout << "\t\t\tWelcome Recruit!\n\n";
	cout << "In order to decript enemy signals you must be able to unscramble simple codewords. ";
	cout << "Initiating training protical..." << endl;
	cout << "Enter 'hint' for a hint";
	cout << "Enter 'quit' to quit the training program" << endl;

	cout << "The code is: " << jumble;

	//Player input
	cout << "\n\nYour guess: ";
	cin >> guessOne;

	//Game loop
	//Word 1 guess
	while ((guessOne != theWord) && (guessOne != "quit"))
	{
		if (guessOne == "hint")
		{
			cout << theHint;
		}
		else
		{
			cout << "Sorry, that's not it.";
		}

		cout << "\n\nYour guess: ";
		cin >> guessOne;
	}

	//Word 2 guess
	if (guessOne == theWord)
	{
		cout << "Good job" << endl;
		cout << "Second code initializing..." << endl;
		cout << "\n\nYour guess: ";
		cin >> guessTwo;
	}

	//Ends the function
	return 0;
}